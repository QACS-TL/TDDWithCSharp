﻿using FindHighestNumberService;

namespace TopicManagerService
{
    public class HighestNumberFinder : IHighestNumberFinder
    {
        public int findHighestNumber(int[] values)
        {
            return 89;
        }
    }
}
