﻿using System;

namespace FindHighestNumberService.v1
{
    public class HighestNumberFinder
    {
        public int findHighestNumber(int[] values)
        {
            return values[0];
        }
    }
}
