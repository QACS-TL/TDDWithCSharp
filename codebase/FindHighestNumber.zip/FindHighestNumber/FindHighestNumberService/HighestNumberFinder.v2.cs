﻿using System;

namespace FindHighestNumberService.v2
{
    public class HighestNumberFinder
    {
        public int findHighestNumber(int[] values)
        {
            return values[0];
        }
    }
}
